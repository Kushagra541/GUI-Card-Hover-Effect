import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel
from PyQt5.QtCore import Qt, QPoint
from PyQt5.QtGui import QTransform

class HoverCard(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("3D Hover Effect")
        self.setGeometry(100, 100, 400, 600)
        self.setStyleSheet("background-color: #f0f0f0;")

        # Create a label that simulates a card
        self.card = QLabel(self)
        self.card.setFixedSize(300, 400)
        self.card.setStyleSheet("""
            background-color: #ffffff;
            border-radius: 20px;
            box-shadow: 5px 10px 20px rgba(0, 0, 0, 0.3);
            text-align: center;
            font-size: 24px;
            padding: 20px;
        """)
        self.card.setText("Hover me!")
        self.card.setAlignment(Qt.AlignCenter)
        self.card.move(50, 100)

        self.center = QPoint(self.card.width() // 2, self.card.height() // 2)

    def mouseMoveEvent(self, event):
        # Calculate the relative mouse position over the card
        card_rect = self.card.geometry()
        if card_rect.contains(event.pos()):
            pos = event.pos() - card_rect.topLeft()
            offset_x = pos.x() - self.center.x()
            offset_y = pos.y() - self.center.y()

            # Apply a rotation transform based on mouse position
            transform = QTransform()
            transform.rotate(-offset_y / 10, Qt.XAxis)
            transform.rotate(offset_x / 10, Qt.YAxis)
            self.card.setGraphicsEffect(None)  # Reset effects to apply transformation
            self.card.setGraphicsEffect(None)
            self.card.setTransform(transform)

    def leaveEvent(self, event):
        # Reset the card when the mouse leaves
        self.card.setTransform(QTransform())  # Reset transform

# Main application logic
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = HoverCard()
    window.show()
    sys.exit(app.exec_())
